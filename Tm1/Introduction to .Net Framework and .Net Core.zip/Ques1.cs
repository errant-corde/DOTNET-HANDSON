﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tm1
{
    class Ques1
    {
        static void Main(string[] args)
        {
            int s;
            Console.WriteLine("Enter the side of a square");
            s = int.Parse(Console.ReadLine());
            Console.WriteLine("Area of the square is {0}", s * s);

        }
    }
}
